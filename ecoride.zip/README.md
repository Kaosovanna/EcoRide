# EcoRide (fr) — Front-end & Back-end séparés

Ce projet sépare clairement la partie **front-end** (interface) et **back-end** (API) pour une intégration facile sur GitHub.

## Arborescence

```
ecoride/
├─ frontend/
│  ├─ index.html
│  ├─ styles.css
│  └─ app.js
└─ backend/
   ├─ server.js
   ├─ covoiturages.json
   └─ package.json
```

## Démarrer l'API (back-end)

1. Installer les dépendances :
   ```bash
   npm install
   ```
2. Lancer le serveur :
   ```bash
   npm start
   ```
   Par défaut l'API écoute sur `http://localhost:3000`.

## Ouvrir le front (front-end)

Ouvrez `frontend/index.html` dans votre navigateur.
Pour pointer le front sur une autre URL d'API, exposez `window.__API_BASE__` dans la console, par exemple :
```js
window.__API_BASE__ = 'http://localhost:3000/api';
```

## Déploiement GitHub

- Publiez `frontend/` via GitHub Pages (branche `gh-pages` ou dossier `docs/`).
- Déployez `backend/` sur un service Node (Railway, Render, Fly.io, etc.).
- CORS est activé par défaut dans l'API.

## Remarques

- Le code, les variables et les commentaires sont en **français**.
- Les données sont de **démonstration**. Remplacez `backend/covoiturages.json` par vos données réelles ou branchez une base de données.
